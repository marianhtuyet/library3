<div class="footer-container container">
    <div class="footer container">
        <h1><span style="font-size: large;"><span style="vertical-align: inherit;"><span
                        style="vertical-align: inherit;">Thư viện Trung t&acirc;m Học vấn Đa Minh</span></span></span>
        </h1>
        <h2><span style="font-size: medium;"><span style="font-family: Calibri, sans-serif;"><span
                        style="vertical-align: inherit;"><span style="vertical-align: inherit;">90 Nguyễn Th&aacute;i Sơn, P.3, G&ograve; Vấp, TP. </span><span
                            style="vertical-align: inherit;">HCM;&nbsp;</span></span></span></span><span
                style="font-size: medium;"><span style="vertical-align: inherit;"><span
                        style="vertical-align: inherit;">Email: <b><i>thuviendaminh@gmail.com</i></b></span></span></span>
        </h2>
        <h2><span style="font-size: medium;">(Copyright &copy; 2016 Thư Viện Đại Chủng Viện Đức Mẹ V&ocirc; Nhiễm B&ugrave;i Chu)</span>
        </h2>
        <p>&nbsp;</p></div>
    <address class="copyright">&copy; 2017 Magento Demo Store. All Rights Reserved.</address>
    <img src="/assets/img/go-top.png" id="go-to-top"/>
</div>
<?php /**PATH C:\xampp\htdocs\library3\resources\views/layouts/footer.blade.php ENDPATH**/ ?>