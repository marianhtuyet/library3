<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Thư viện Trung tâm học vấn Đaminh </title>
    <meta name="description" content="Default Description"/>
    <meta name="keywords" content="Magento, Varien, E-commerce"/>
    <meta name="robots" content="INDEX,FOLLOW"/>


    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/assets/css/style-demo.css" media="all"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/style.css" media="all"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css" media="all"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/jquery.bxslider.css" media="all"/>
    <!-- Vendor CSS Files -->
    <link href="/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    
    <script type="text/javascript" src="/js/prototype/prototype.js"></script>
    <script type="text/javascript" src="/js/lib/jquery/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="/js/lib/jquery/noconflict.js"></script>
    <script type="text/javascript" src="/js/lib/ccard.js"></script>
    <script type="text/javascript" src="/js/prototype/validation.js"></script>
    <script type="text/javascript" src="/js/scriptaculous/builder.js"></script>
    <script type="text/javascript" src="/js/scriptaculous/effects.js"></script>
    <script type="text/javascript" src="/js/scriptaculous/dragdrop.js"></script>
    <script type="text/javascript" src="/js/scriptaculous/controls.js"></script>
    <script type="text/javascript" src="/js/scriptaculous/slider.js"></script>
    <script type="text/javascript" src="/js/varien/js.js"></script>
    <script type="text/javascript" src="/js/varien/form.js"></script>
    <script type="text/javascript" src="/js/mage/translate.js"></script>
    <script type="text/javascript" src="/js/mage/cookies.js"></script>
    <script type="text/javascript" src="/js/lib/modernizr.custom.min.js"></script>
    <script type="text/javascript" src="/js/lib/selectivizr.js"></script>
    <script type="text/javascript" src="/js/lib/matchMedia.js"></script>
    <script type="text/javascript" src="/js/lib/matchMedia.addListener.js"></script>
    <script type="text/javascript" src="/js/lib/enquire.js"></script>


    <script type="text/javascript" src="/js/app.js"></script>
    <script type="text/javascript" src="/js/lib/jquery.cycle2.min.js"></script>
    <script type="text/javascript" src="/js/lib/jquery.cycle2.swipe.min.js"></script>
    <script type="text/javascript" src="/js/slideshow.js"></script>
    <script type="text/javascript" src="/js/lib/imagesloaded.js"></script>
    <script type="text/javascript" src="/js/minicart.js"></script>
    <script type="text/javascript" src="/js/thuvien_common.js"></script>
    <script type="text/javascript" src="/jcarousellite/js/jquery.jcarousellite.js"></script>
    <script type="text/javascript" src="/jcarousellite/js/jquery.easing-1.3.js"></script>
    <script type="text/javascript" src="/jcarousellite/js/jquery.mousewheel-3.1.12.js"></script>
    <script type="text/javascript" src="/bxslider/jquery.bxslider.min.js"></script>
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Raleway:300,400,500,700,600"/>
    <!--[if (gte IE 9) | (IEMobile)]><!-->

        <!--<![endif]-->

            
    
    
    
    

<meta name="viewport" content="initial-scale=1.0, width=device-width"/>

<script type="text/javascript">
        //<![CDATA[
        optionalZipCountries = ["IE", "HK", "MO", "PA"];
        //]]>
    </script>
    <script type="text/javascript">//<![CDATA[
    var Translator = new Translate({
        "Please select an option.": "Ph\u1ea3i ch\u1ecdn m\u1ed9t gi\u00e1 tr\u1ecb.",
        "This is a required field.": "Ph\u1ea3i nh\u1eadp th\u00f4ng tin.",
        "Please enter a valid date.": "H\u00e3y nh\u1eadp ng\u00e0y h\u1ee3p l\u1ec7.",
        "Please enter a valid email address. For example johndoe@domain.com.": "H\u00e3y nh\u1eadp \u0111\u1ecba ch\u1ec9 email, v\u00ed d\u1ee5: abc@domain.com",
        "Please make sure your passwords match.": "H\u00e3y ki\u1ec3m tra xem m\u1eadt kh\u1ea9u gi\u1ed1ng nhau ch\u01b0a.",
        "Please enter a valid $ amount. For example $100.00.": "H\u00e3y nh\u1eadp \u0111\u00fang s\u1ed1 l\u01b0\u1ee3ng \u0110\u00f4 La. V\u00ed d\u1ee5 $100.00.",
        "Please select one of the above options.": "Ph\u1ea3i ch\u1ecdn m\u1ed9t gi\u00e1 tr\u1ecb.",
        "Please select one of the options.": "Ph\u1ea3i ch\u1ecdn m\u1ed9t gi\u00e1 tr\u1ecb.",
        "Please select State\/Province.": "H\u00e3y ch\u1ecdn t\u1ec9nh ho\u1eb7c v\u00f9ng.",
        "Card type does not match credit card number.": "Lo\u1ea1i th\u1ebb thanh to\u00e1n kh\u00f4ng \u0111\u00fang v\u1edbi s\u1ed1 th\u1ebb.",
        "Please enter a number lower than 100.": "H\u00e3y nh\u1eadp s\u1ed1 nh\u1ecf h\u01a1n 100.",
        "Please wait, loading...": "Ch\u1edd ch\u00fat, \u0111ang t\u1ea3i...",
        "This date is a required value.": "Ph\u1ea3i nh\u1eadp th\u00f4ng tin.",
        "Please enter a valid day (1-%d).": "H\u00e3y nh\u1eadp ng\u00e0y h\u1ee3p l\u1ec7 (1-%d).",
        "Please enter a valid full date": "H\u00e3y nh\u1eadp ng\u00e0y \u0111\u1ea7y \u0111\u1ee7 h\u1ee3p l\u1ec7",
        "Complete": "Ho\u00e0nh th\u00e0nh",
        "Add Products": "Th\u00eam s\u1ea3n ph\u1ea9m",
        "Please specify payment method.": "B\u1ea1n ph\u1ea3i ch\u1ecdn ph\u01b0\u01a1ng th\u1ee9c thanh to\u00e1n.",
        "Add to Cart": "\u0110\u1eb7t mua",
        "In Stock": "C\u00f2n h\u00e0ng",
        "Out of Stock": "H\u1ebft h\u00e0ng"
    });
    //]]></script>
</head>
<?php /**PATH C:\xampp\htdocs\library3\resources\views/layouts/interface.blade.php ENDPATH**/ ?>