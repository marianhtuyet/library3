<!-- Extends template page -->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>

<div class="main-container col1-layout">
    <div class="main">
        <div class="col-main">
            <div class="title">
                <h3>Edit Author</h3>
            </div>


            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">

                    <!-- Alert message (start) -->
                    <?php if(Session::has('message')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class')); ?>">
                      <?php echo e(Session::get('message')); ?>

                  </div>
                  <?php endif; ?>
                  <!-- Alert message (end) -->


                  <div class="actionbutton">

                    <a class='btn btn-info float-right' href="<?php echo e(route('author')); ?>">List</a>

                </div>

                <form action="<?php echo e(route('author.update',[$author->id])); ?>" method="post" >
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="name" class="form-control col-md-12 col-xs-12" name="name" placeholder="Enter author name" required="required" type="text" value="<?php echo e(old('name',$author->name)); ?>">

                            <?php if($errors->has('name')): ?>
                            <span class="errormsg"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Is translator
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="checkbox" id="is_translator" name="is_translator" value="<?php echo e($author->is_translator); ?>" 
                            <?php echo e($author->is_translator ? 'checked' : ''); ?>  onclick="recompute_check_box(this);"  />
                            `                
                            <script type="text/javascript">

                                function  recompute_check_box(obj){
                                 if(!obj.checked){  
                                    obj.value= "0";
                                    
                                } 
                                else 
                                    obj.value = "1";
                                
                            }

                        </script>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6">

                        <input type="submit" name="submit" value='Submit' class='btn btn-success'>
                    </div>
                </div>

            </form>

        </div>
    </div>


    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library3\resources\views/author/edit.blade.php ENDPATH**/ ?>