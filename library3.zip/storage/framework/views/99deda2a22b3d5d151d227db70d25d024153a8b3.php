<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>

<div class="main-container col1-layout">
    <div class="main">
        <div class="col-main">
            <div class="title">
                <h3>Authors List</h3>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <!-- Alert message (start) -->
                    <?php if(Session::has('message')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class')); ?>">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Alert message (end) -->

                    <div class='actionbutton'>

                        <a class='btn btn-info float-right' href="<?php echo e(route('author.create')); ?>">Add</a>
                        
                    </div>
                    <table class="table" >
                        <thead>
                            <tr>
                                <th width='40%'>Name</th>
                                <th width='40%'>Is translator</th>
                                <th width='20%'>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($author->name); ?></td>
                                <td> <?php if($author->is_translator): ?>
                                    <input type="checkbox" name="is_translator" value="check" checked readonly="true"/>
                                    <?php else: ?>
                                    <input type="checkbox" name="is_translator" value="check" readonly="true"  />
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Edit -->
                                    <a href="<?php echo e(route('author.edit',[$author->id])); ?>" class="btn btn-sm btn-info">Edit</a>
                                    <!-- Delete -->
                                    <a href="<?php echo e(route('author.delete',$author->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library3\resources\views/author/index.blade.php ENDPATH**/ ?>