<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>

<div class="main-container col1-layout">
    <div class="main">
        <div class="col-main">
            <div class="title">
                <h3>DDC List</h3>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <!-- Alert message (start) -->
                    <?php if(Session::has('message')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class')); ?>">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Alert message (end) -->

                    <div class='actionbutton'>

                        <a class='btn btn-info float-right' href="<?php echo e(route('tpddcs.create')); ?>">Add</a>
                        
                    </div>
                    <table class="table" >
                        <thead>
                            <tr>
                                <th width='40%'>Name</th>
                                <th width='40%'>DDC</th>
                                <th width='20%'>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tpddcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpddc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tpddc->ddc_name); ?></td>

                                <td>
                                    <?php echo e($tpddc->ddc); ?>

                                 
                                </td>
                                <td>
                                    <!-- Edit -->
                                    <a href="<?php echo e(route('tpddcs.edit',[$tpddc->id])); ?>" class="btn btn-sm btn-info">Edit</a>
                                    <!-- Delete -->
                                    <a href="<?php echo e(route('tpddcs.delete',$tpddc->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library3\resources\views/tpddcs/index.blade.php ENDPATH**/ ?>